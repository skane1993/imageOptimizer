<?php

	define( "MAIN_TITLE", "Optimisation d'images");

	define( "MY_COMPANY", "Vizion'R");
	define( "MY_COMPANY_CONTACT", "contact@vizionr.fr");

	define( "ALGOFAB_BANNER", "images/BandeauAlgoFab_5.jpg");

	define( "ALGO_LOGO", "images/algofab_algo.png");

	define( "MY_LOGO", "images/algofab.png");
	define( "MY_LOGO_TINY", "images/algofab_icon.png");

	define( "MY_ALGO_TITLE", "ImageOptimizer");
	define( "MY_ALGO_DESCRIPTION", "<strong>ImageOptimizer</strong> utilise des métriques perceptuelles pour procéder à l'optimisation automatique d'images JPEG afin d'en minimiser le poids au maximum sans altérer la qualité perçue.");
	define( "MY_ALGO_TRY_IT_TITLE", "Essayer l'agorithme");
	define( "MY_ALGO_TRY_IT_LOAD_IMAGE", "Chargez une image JPEG (*.jpg, *.jpeg)");
	define( "OPTIMIZE_BUTTON_LABEL", "Optimiser !");
	define("IMAGES_FOLDER_IN", "upload/");
	define("IMAGES_FOLDER_OUT", "download/");
	define( "RESULT_TITLE", "Résultats");
	define( "RESULT_IMAGE_IN", "Image Source");
	define( "RESULT_IMAGE_OUT", "Image Optimisée");
	define( "MAIN_DESCRIPTION", "Algorithme d'optimisation automatique d'images");
	define( "MAIN_DESCRIPTION_SUB", "Notre algorithme utilise des métriques perceptuelles pour procéder à l'optimisation automatique d'images JPEG afin d'en minimiser le poids au maximum sans altérer la qualité perçue.");
	define( "MAIN_TITLE", "Optimisation d'images");
	define( "MAIN_IMAGE", "images/vizionr.png");


	define( "MY_ALGO_API_TITLE", "Comment utiliser notre algorithme");
	define( "MY_ALGO_API_DESCRIPTION", "Cette section décrit les différents formats d'images supportés par l'algorithme, la procédure d'appel du service d'optimisation ainsi que les formats de requête et de réponse.");
	define( "MY_ALGO_API_SUPPORTED_FORMATS", "<p>Seules les images <b>JPEG</b> (.jpg, .jpeg) sont supporteés. <br/>
Le poids maximal autorisé pour une utilisation en ligne est de <b>10Mo</b>.</p>");
	define( "MY_ALGO_API_REQUEST", "<p>L'image à optimiser doit être disponible en HTTP. <br/>
La requête s'effectue comme un appel de webservice REST, en passant en paramètre GET : </p>
<ul>
    <li>Le token d'authentification fourni (paramètre GET <b>token</b>)</li>
    <li>L'URL de l'image à optimiser (paramètre GET <b>resource</b>)</li>
    <li>Le type de réponse souhaité (paramètre GET <b>kind</b>) :
		<ul>
		    <li><b>JSON</b> : Le service génère un fichier JSON de description de la réponse, contenant un lien temporaire vers l'image générée.</li>
		    <li><b>RAW</b> : Le service renvoie directement l'image générée au client (ou une image vide en cas d'erreur).</li>
		</ul>
	</li>
</ul>

<br />
<br />
<br />


<p>
	Exemples :
	<ul>
		<li>Pour obtenir une réponse de type JSON :
			<code>
				http://service_api_url/optimize?<b>resource</b>=http%3A%2F%2Fwebsite.com%2Fr%2Fimage.jpg&<b>kind</b>=JSON&token=80ca-ecb1ea61258e
			</code>
		</li>
		<li>Pour obtenir une réponse de type image :
			<code>http://service_api_url/optimize?<b>resource</b>=http%3A%2F%2Fwebsite.com%2Fr%2Fimage.jpg&<b>kind</b>=RAW&<b>token</b>=80ca-ecb1ea61258e</code>
		</li>
	</ul>
</p>
");
	define( "MY_ALGO_API_RESPONSE", "<p>Si la requête est de type <b>RAW</b>, le résultat est directement l'image générée par le service. Si une erreur s'est produite durant l'exécution de l'algorithme, une image vide est renvoyée.</p>

<br />

<p>
	Si la requête est de type JSON, le résultat est un fichier JSON contenant les champs suivants :
	<ul>
		<li><b>date</b> : la date d'exécution du service</li>
		<li><b>executionTime</b> : la durée de l'éxécution de l'algorithme (en secondes)</li>
		<li><b>source</b> : rappel de l'URL de l'image source</li>
		<li><b>target</b> : URL vers l'image générée</li>
		<li><b>targetExpire</b> : durée de validité du lien d'image généré (en secondes)</li>
		<li><b>sourceWeight</b> : le poids en octets de l'image source</li>
		<li><b>targetWeight</b> : le poids en octets de l'image optimisée</li>
		<li><b>compressionRate</b> : le taux de compression de l'image obtenue (de 0 à 1)</li>
	</ul>
</p>
<p/>
	Exemple de réponse JSON:
	<pre>
		<code>
{
	\"date\": \"2016-12-01T09:30:10\",
	\"executionTime\": 0.112,
	\"source\": \"http://website.com/image.jpg\",
	\"target\": \"http://service_api_url/optimized/temp/435SFJDSf4.jpg\",
	\"targetExpire\": 3600,
	\"sourceWeight\": 4532435,
	\"targetWeight\": 1546562,
	\"optimisationRate\": 0.3412	
}	
		</code>
	</pre>
</p>
");





	function createHeader(){
		echo '
	
			<meta charset="utf-8">
			<meta http-equiv="X-UA-Compatible" content="IE=edge">
			<meta name="viewport" content="width=device-width, initial-scale=1">
			<meta name="description" content="ALGOFAB">
			<meta name="author" content="ALGOFAB">
			<link rel="icon" href="' . MY_LOGO_TINY . '">

			<title>' . MAIN_TITLE . '</title>

			<link href="css/bootstrap.min.css" rel="stylesheet">
			<link href="css/main.css" rel="stylesheet">
			<link href="css/business-frontpage.css" rel="stylesheet">
			<script src="js/jquery.min.js"></script>
			<script src="js/bootstrap.min.js"></script>
			<script src="js/jquery-ui/jquery-ui.js"></script>
	
		<style>
			.bandeau{
				position:absolute;
				top:0px;
				width:100%;
				height:250px;			
				background: url(\'' . ALGOFAB_BANNER . '\') center center no-repeat scroll;

			}
			body {
				padding-top: 70px;	
			}
			</style>'
		;

	}

	function createNavBar($page){

		echo '		
	    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
			<div class="container-fluid">
			  <div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
				  <span class="sr-only">Toggle navigation</span>
				  <span class="icon-bar"></span>
				  <span class="icon-bar"></span>
				  <span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" href="index.php"><img style="height:32px" src="' . ALGO_LOGO. '"></img></a>
			  </div>
			  <div id="navbar" class="navbar-collapse collapse">
				<ul class="nav navbar-nav">
			<li  ' . ($page == "overview" ? 'class="active"' : '') . '><a href="index.php">Accueil</a></li>
			<li  ' . ($page == "api" ? 'class="active"' : '') . '><a href="api.php">API</a></li>
			<li  ' . ($page == "demo" ? 'class="active"' : '') . '><a href="demo.php">Démonstration</a></li>
		
				</ul>
				<ul class="nav navbar-nav navbar-right">
				  <li><a href="./"></a></li>
				</ul>
			  </div>
			</div>
			</nav>
		
			<div class="bandeau"></div>
			<div style="padding-top:200px;"></div>
		';

	}

	function createFooter(){
		echo '
		<!-- Footer -->
		<div class="container">
			<hr/>
		<footer>
		    <div class="row">
		        <div class="col-lg-12">
		            <p>Copyright &copy; ' . MY_COMPANY.'  2016-2017</p>
		        </div>
		    </div>
		    <!-- /.row -->
		</footer>
		</div>
		';
	
	}

	function startsWith($haystack, $needle) {
	    return $needle === "" || strrpos($haystack, $needle, -strlen($haystack)) !== false;
	}

	function endsWith($haystack, $needle) {
	    return $needle === "" || (($temp = strlen($haystack) - strlen($needle)) >= 0 && strpos($haystack, $needle, $temp) !== false);
	}

	function purgeUploadDir($dir){
		$allImages = scandir($dir);
		foreach($allImages as $im){
		        $im = $dir . "/" . $im;
		        if(is_dir($im)) continue;
		        $path = pathinfo($im);
		        $ext = strtoupper($path["extension"]);
		        if(!in_array($ext, array("PNG", "JPG", "JPEG", "GIF", "BMP"))) continue;
		        $lm = filemtime($im);
		        if(time() - $lm < 3600 * 24 * 7) {
		                 continue;
		         }
		        unlink($im);
		}
	}

?>
