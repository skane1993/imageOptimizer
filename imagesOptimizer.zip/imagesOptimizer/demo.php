<?php
require_once "php/info.php";


//images folder cleanup
purgeUploadDir(IMAGES_FOLDER_IN);
purgeUploadDir(IMAGES_FOLDER_OUT);

//print_r($_POST);

$currentImageIn = "";
$currentImageOut = "";

$currentImageInSize = 0;
$currentImageOutSize = 0;


$message = "";
$error = false;

//then gets from POST
if(isset($_POST["updateImage"])){
	
	//gets image
	if($_FILES['inputImage'] && $_FILES['inputImage']['size']){
			$imageData = $_FILES['inputImage'];
			$imageName = $imageData['name'];
			$imageName = preg_replace('/[^A-Za-z0-9_\-\.]/', '_', $imageName);
			$ext = pathinfo($imageName, PATHINFO_EXTENSION);
			$extUp = strtoupper($ext);
			if($extUp != "JPEG" && $extUp != "JPG"){
				$error = true;
				$message = "Vous devez charger une image jpeg !";
			}else{				
				$imageName = $imageName . rand() . "." . $ext;
				$imageNameOut = $imageName . rand() . "." . $ext;
				$imageTmpPath = $imageData['tmp_name'];
				$ok = ($imageData['error']==0);
				if($ok){
					move_uploaded_file($imageTmpPath, IMAGES_FOLDER_IN . $imageName);
					$currentImageIn = IMAGES_FOLDER_IN . $imageName;
					
					//then processes it
					$currentImageOut = IMAGES_FOLDER_OUT . $imageNameOut;
					copy($currentImageIn, $currentImageOut);
					
					//set_time_limit(100);
					$cmd = "cd app && java -Dvizionr.exe.dir=resources/ -jar bin/imagesOptimizer.jar \"" . realpath($currentImageIn) . "\" \"" . realpath($currentImageOut) . "\" \"temp/\"";
					exec($cmd, $output, $result);
					//echo "<br/>" . $cmd;
					//echo "<br/>RESULT:" . $result . "<br/>";
					//print_r($output);
					
					if(exif_imagetype($currentImageOut) == IMAGETYPE_JPEG){
						$currentImageOut2 = IMAGES_FOLDER_OUT . $imageName . rand() . ".jpg";
						copy($currentImageOut, $currentImageOut2);
						$currentImageOut = $currentImageOut2;
					}
					
					if(!file_exists($currentImageOut)){
						copy($currentImageIn, $currentImageOut);
						$error = true;
						$message = "L'image n'a pas pu être compressée davantage";					
					}
					else{
						$error = false;
						$message = "L'image a été compressée avec succès";
					}
					
				}else{
					$error = true;
					$message = "Erreur lors du transfert de l'image";
				}
			}
	}
	else{
		$error = true;
		$message = "Vous devez spécifier une image !";
	}

}

if($currentImageIn){
	$currentImageInSize = (filesize($currentImageIn)/1000) . " ko";
}
if($currentImageOut){
	$currentImageOutSize = (filesize($currentImageOut)/1000) . " ko";
}


?>
<!DOCYTPE html>
<html>
	<head>
		<?php createHeader();?>

	</head>
	<body>
		<?php createNavBar("demo"); ?>
		<?php
			if(strlen($message)>0){
				$class="label label-default";
				if($error)
					$class="label label-danger";
				echo '<div class="container">
					<div id="errorMsg" class="' . $class . '" style="display:block">' . $message .'</div>
				      </div>';
			}
		?>
<!--
		<div class="container">
			<hr>
			<div class="row">
				<div class="col-sm-12">
					<h2><?php echo MY_ALGO_TRY_IT_TITLE;?></h2>
					
					<p><?php echo MY_ALGO_TRY_IT_DESCRIPTION;?></p>
					<br/>
				</div>
			</div>
		</div>
-->		
		<div class="container">
			<div class="jumbotron">
				<h1><?php echo MAIN_DESCRIPTION?></h1>
				<p><?php echo MAIN_DESCRIPTION_SUB?></p>
			</div>
		</div>
		
		
		<div class="container">
			<div class="panel panel-default">
				<div class="panel-heading">
					<h3 class="panel-title"><?php echo MY_ALGO_TRY_IT_TITLE?></h3>
				</div>	
				<div class="panel-body">
					<div class="container">
						<form name="tryAlgo" method="POST" enctype="multipart/form-data">
							<h3><?php echo MY_ALGO_TRY_IT_LOAD_IMAGE?></h3>
							<input type="file" name="inputImage" accept="image/jpg, image/jpeg">
							<br/>
							<input type="submit" value="<?php echo OPTIMIZE_BUTTON_LABEL?>">
							<input type="hidden" name="updateImage" value="1">
						</form>
					</div>
				</div>
			</div>
			<div class="panel panel-default">
				<div class="panel-heading">
					<h3 class="panel-title"><?php echo RESULT_TITLE?></h3>
				</div>	
				<div class="panel-body">
					<div class="container">
						<table>
							<tr><td><span class="label label-primary"><?php echo RESULT_IMAGE_IN?></span><?php if($currentImageInSize) echo "&nbsp;(" . $currentImageInSize.")";?></td></tr>
							<tr><td><?php if($currentImageIn) echo '<img style="max-height:300px" src="' . $currentImageIn . '"/>'; else echo "Aucune image chargée."?></td></tr>
							<tr><td><span class="label label-primary"><?php echo RESULT_IMAGE_OUT?></span><?php if($currentImageOutSize) echo "&nbsp;(" . $currentImageOutSize.")";?></td></tr>
							<tr><td><?php if($currentImageOut) echo '<img style="max-height:300px" src="' . $currentImageOut . '"/>'; else echo "Aucune image chargée."?></td></tr>
						</table>
					</div>
				</div>
			</div>
		</div>
		<?php createFooter(); ?>
</body>

</html>
