<?php
require_once "php/info.php";

?>
<html>
	<head>
		<?php createHeader();?>
	</head>
	<body>
		<?php createNavBar("api"); ?>

		<div class="container">
			<hr>
			<div class="row">
				<div class="col-sm-12">
					<h2><?php echo MY_ALGO_API_TITLE;?></h2>
					<p><?php echo MY_ALGO_API_DESCRIPTION;?></p>
					<br/>
				</div>
			</div>
			<hr/>
		</div>

		<div class="container">
			<div class="panel panel-default">
				<div class="panel-heading">
					<h3 class="panel-title">Formats supportés</h3>
				</div>	
				<div class="panel-body">
					<div class="container">
						<?php echo MY_ALGO_API_SUPPORTED_FORMATS;?>						
					</div>
				</div>
			</div>
			
			<div class="panel panel-default">
				<div class="panel-heading">
					<h3 class="panel-title">Envoyer une requête d'optimisation d'image</h3>
				</div>	
				<div class="panel-body">
					<div class="container">
						<?php echo MY_ALGO_API_REQUEST;?>
					</div>
				</div>
			</div>
			
			<div class="panel panel-default">
				<div class="panel-heading">
					<h3 class="panel-title">Format de réponse</h3>
				</div>	
				<div class="panel-body">
					<div class="container">
						<?php echo MY_ALGO_API_RESPONSE;?>
					</div>
				</div>
			</div>

		</div>
		
		<?php createFooter();?>

	</body>
</html>
