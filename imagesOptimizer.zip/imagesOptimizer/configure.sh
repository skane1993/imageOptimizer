chmod -R a+rw *
chmod a+rwx app/bin/imagesOptimizer.jar
chmod a+rwx app/imagesOptimizer.sh
chmod -R a+rwx app/resources/*
