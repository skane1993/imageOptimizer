java -Dvizionr.exe.dir=resources/ -jar bin/imagesOptimizer.jar $1 $2 "temp/"
