<?php
require_once "php/info.php";

?>
<html>
	<head>
		<?php createHeader();?>
	</head>
	<body>
		<?php createNavBar("overview"); ?>

		<div class="container">
			<hr>
			<div class="row">
				<div class="col-sm-8">
					<h2><?php echo MY_ALGO_TITLE;?></h2>
					
					<p><?php echo MY_ALGO_DESCRIPTION;?></p>
					<br/>
				</div>
				<div class="col-sm-4">
					<h2>Nous contacter</h2>
					<table>
						<tr>
							<td><img style="height:48px" src="images/Mail-icon.png"/></td>
							<td><a href="mailto:<?php echo MY_COMPANY_CONTACT;?>"><?php echo MY_COMPANY_CONTACT;?></a></td>
						</tr>
						<tr>
							<td colspan="2"><img style="height:50px" src="<?php echo MAIN_IMAGE;?>"/></td>
						</tr>
					</table>
				</div>
			</div>
		</div>
	
		<?php createFooter();?>

	</body>
</html>
